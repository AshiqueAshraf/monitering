# readme.txt
# 
# This shell Config.sh is written by Chao,Zhang(104656305),March 27,2017
# Usage:Configure server name,server port,server number and twitter account then show configuration.
#       1.configure local server
#       2.configure cluster server
#       3.configure twitter account
#       4.show local server configuration
#       5.show cluster server configuration
#       6.show twitter configuration
#
# This Config.sh can create a file called Server.config then append information into it,used by server owner.
# Then he can use the C file to get access to those information and process it.
# Basically,C file will find the certain tag,target the speific item then get the value of it for further use.
#
# Apart from the shell file,I also attach a sample file of Server.config here.
